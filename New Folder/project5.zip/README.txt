Name: DOU Daihui
Student ID: 20329361

I'm sorry that I didn't finish the HTML and file part. Please give me partial marks.